import InstructionsPanel from "./instructionsPanel.js";

import eventsCenter from './eventsCenter.js';
import { saveSPEData } from "./db/saveData.js";

var gameHeight;
var gameWidth;

var numTaskBlocks;

var infoButton;
var quitButton;

var showPercInstructionsButton;
var showMemInstructionsButton;
var startPercPracticeButton;
var startMemPracticeButton;
var practPercGameButton;
var practMemGameButton;
var practPercGameState = -1;
var practMemGameState = -1;
var practPercInstrState = -1;
var practMemInstrState = -1;
var practPercPracticeState = -1;
var practMemPracticeState = -1;
var taskButtons = {};
var sret2Button;
var doneButton;
var fullscreenButton;
var curPracticeTask = 0;

var titleText = 'Welcome to Fruitville!'
        
/////////////////PAGE ONE////////////////////
var mainText;
var buttonTxt;
var pageNo;
var nextTaskBtnIndex;

var bannerText;
var helpTextInstr;
var flickerText = undefined;
var content;
var onsetTime;
var transferSameOrOpposite;
var speSlider;
var currentConfidence;
var discreteConfidence;
var text_conf;

const flickerInstructionsFrames = [30, 40];
var curFlickFrame;
var clickConfidence;
var spePractice;

var participantInfoScrollPanel;
var cursors;

var taskPhase;

var welcomTextCenter = {x: 180, y: 40}

export default class Fruitville extends Phaser.Scene{
    constructor (){
        super({
            key: 'fruitville',
        });
    }

    preload (){
   
        this.load.scenePlugin({
            key: 'rexuiplugin',
            url: './src/phaser/rexuiplugin.min.js',
            sceneKey: 'rexUI'
        });  

        this.load.spritesheet('fullscreen', './assets/fullscreen.png', {frameWidth: 64, frameHeight: 64})
        this.load.image('tree','./assets/tree_2.png', { frameWidth: 500, frameHeight: 500 })
   
        this.load.image('bg', './assets/clouds.png');
        this.load.spritesheet('tiles', './assets/fantasy-tiles.png', { frameWidth: 64, frameHeight: 64 });            

        this.load.text('welcomeFruitville', './assets/welcomeFruitville.txt');
        this.load.text('participantInfoSheet', './assets/participantInfoSheet.txt');
        this.load.image('tickMarkGreen', './assets/2705.png');
    }

    create (){      
        // background image
        this.add.image(400, 0, 'bg').setOrigin(0.5, 0.02);
      
        // tiles at the bottom
        for (let i = 0; i < 13; i++){
            this.add.image(64 * i, 580, 'tiles', 1).setOrigin(0);
        }

        gameHeight = this.sys.game.config.height;
        gameWidth = this.sys.game.config.width;

        // define cursor keys
        cursors = this.input.keyboard.createCursorKeys();

        if (window.subjGroup==undefined){ window.subjGroup=1; }
        specifyGroupSpecificParameters(window.subjGroup);
        
        this.createTextAndButtons();
        this.createPercTaskButtons();
        this.createMemTaskButtons();
        numTaskBlocks = window.blockSequence.length;

        // console.log(window.blockSequence)

        // check if participant belongs to group doing (0) only perc, (1) only mem, or (2) both tasks
        transferSameOrOpposite = window.blockSequence[0]==window.blockSequence[1] ?
            window.blockSequence[0] : 2;  

        spePractice = false;

        console.log('stage: '+window.fruitvilleStage)
        switch (window.fruitvilleStage){
            case 0:
                // start the perception task practice
                practPercGameState = 1;
                practMemGameState = 0;
                helpTextInstr.text = 'Click here to \npractice the >>\nfirst game';

                if (!transferSameOrOpposite){
                    // only perception task
                    helpTextInstr.text = 'Click here to \npractice the >>\ngame';
                }

                bannerText.x = gameWidth;

                helpTextInstr.x = 5;
                helpTextInstr.y = 170;

                taskPhase = 'welcome';

                break;

            case 1:
                practPercGameState = 2;
                practPercInstrState = 1;
                practPercPracticeState = 0;
                
                practMemGameState = 0;

                if (!transferSameOrOpposite){
                    // only perception task
                    practMemGameState = -1;
                }

                helpTextInstr.text = 'Instructions \nhere    >>';
                helpTextInstr.x = 5;
                helpTextInstr.y = 280;

                taskPhase = 'enablePracticeTasks';
                break;

            case 2:
                practPercGameState = 2;
                practPercInstrState = 3;
                practPercPracticeState = 1;

                practMemGameState = 0;

                helpTextInstr.text = 'Start \npractice >>';
                helpTextInstr.x = 30;
                helpTextInstr.y = 360;
                
                taskPhase = 'enablePracticeTasks';
                break;

            case 3:
                // when coming back from the first (perception) practice task and starting the SPE
                practPercGameState = 2;
                practPercInstrState = 2;
                practPercPracticeState = 2;

                practMemGameState = 0;

                this.children.bringToTop(helpTextInstr);
                helpTextInstr.text = '   Drag slider to estimate how\n<< many trials you got correct.\n   Then press the right key (->) to\n   proceed.';
                helpTextInstr.x = 370;
                helpTextInstr.y = 395;
                
                spePractice = true;

                taskPhase = 'enablePracticeTasks';

                break;                        
                
            case 4:
                // for DEBUG mode - when starting only with the practice run
                practPercGameState = 3;
                practPercInstrState = -1;
                practPercPracticeState = -1;

                practMemGameState = 2;
                practMemInstrState = 1;
                practMemPracticeState = 0;

                taskPhase = 'enablePracticeTasks';
                break;
                
            case 5:
                practPercGameState = 2;
                practPercInstrState = -1;
                practPercPracticeState = -1;

                practMemGameState = 2;
                practMemInstrState = 3;
                practMemPracticeState = 1;

                helpTextInstr.text = 'Start \npractice >>';
                // if (transferSameOrOpposite==1){
                //     // only memory task
                //     helpTextInstr.text = 'Click here to \npractice the >>\ngame';
                // }
                helpTextInstr.x = 340;
                helpTextInstr.y = 360;
                
                taskPhase = 'enablePracticeTasks';
                break;       

            case 9:
                practPercGameState = -1;
                practPercInstrState = -1;
                practPercPracticeState = -1;

                practMemGameState = 1;
                practMemInstrState = -1;
                practMemPracticeState = -1;

                // this.children.bringToTop(helpTextInstr);
                helpTextInstr.text = 'Click here to \npractice the >>\ngame';
                helpTextInstr.x = 310;
                helpTextInstr.y = 170;
                taskPhase = 'enablePracticeTasks';     
                
                break;

            case 6:
                // when coming back from the second (memory) practice task and starting the SPE
                practPercGameState = -1;
                practMemGameState = 2;
                practMemInstrState = 3;
                practMemPracticeState = 2;
                spePractice = true;

                this.children.bringToTop(helpTextInstr);
                helpTextInstr.text = 'Drag slider to estimate how  \nmany trials you got correct. >>\nThen press the right key (->) to\nproceed.';
                helpTextInstr.x = 100;
                helpTextInstr.y = 400;

                taskPhase = 'enablePracticeTasks';
                break;

            case 7:
                // when only doing the perception (and not the memory task) during practice go to spe
                practPercGameState = 2;
                practPercInstrState = 3;
                practPercPracticeState = 2;
                practMemGameState = -1;
                practMemInstrState = -1;
                practMemPracticeState = -1;
                // window.practiceOrFinal = [1,1];
                spePractice = true;

                taskPhase = 'enablePracticeTasks';
                break;               

            case 8:
                // after returning from a block of the final task, get the SPE
                practPercGameState = -1;
                practMemGameState = -1;
                practMemInstrState = -1;
                practMemPracticeState = -1;
                window.practiceOrFinal = [1,1];
                clickConfidence = false;
                taskPhase = 'speFinal';
                break;

            case 10:
                // after coming back from the second SRET block continue with the fifth final task
                window.sret2State = -1;
                taskPhase = 'enableFinalTasks';

        }

        // taskPhase = 'practiceCompleteMessage';

        if (!transferSameOrOpposite){
            // only perception task
            practMemGameState = -1;
            practMemInstrState = -1;
            practMemPracticeState = -1;
        }
        else if(transferSameOrOpposite==1){
            // only memory task
            practPercGameState = -1;
            practPercInstrState = -1;
            practPercPracticeState = -1;
        }

        for (let i = 0; i<numTaskBlocks; i++){
            // create the buttons for the final task
            taskButtons[i] = createButton(this, 
                !window.blockSequence[i] ? (i+1)+". Berry Yield": (i+1)+'. Fruit Box', 
                { // position
                x: -20 + i*120 + (i%2)*110 + ((i+1)%2)*120, 
                y: 280 + (i%2)*90, 
                width: 110, height: 70},
                function(scene) { // click callback
                    // console.log(nextTaskBtnIndex)
                    window.finalTaskState[nextTaskBtnIndex] = 2;
                    if (nextTaskBtnIndex<numTaskBlocks){
                        // window.finalTaskState[++nextTaskBtnIndex] = 1;
                    }
                    else{
                        // study complete!!
                        window.mainTaskState = 2;
                        scene.scene.start("welcome");
                    }
                    scene.scene.start(window.blockSequence[i] ? 
                        "memoryTask" : "perceptionTask");
            });
            taskButtons[i].setVisible(false);
        }

        onsetTime = window.performance.now();
        content = undefined;

    }

    update (){

        switch(taskPhase){

            case 'welcome':
                if (bannerText.x > welcomTextCenter.x && 
                    (onsetTime - window.performance.now() < 10)){
                    bannerText.x = bannerText.x-50;//5;
                    onsetTime = window.performance.now();
                }
                else{
                    taskPhase = 'welcome2Fruitville';
                }

                break;

            case 'welcome2Fruitville':

                enableButton(quitButton,0);
                enableButton(infoButton,0);
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                pageNo, titleText, mainText, buttonTxt);
                    
                eventsCenter.once('page1complete', function () {
                    enableButton(quitButton,1);
                    enableButton(infoButton,1);

                    taskPhase = 'enablePracticeTasks';
                }, this);

                taskPhase = 'wait';
                break;

            case 'showParticipantInfoSheet':

                infoButton.setVisible(false);
                quitButton.setVisible(false);

                if (content==undefined){
                    content = loadInfoSheet(this);
                    participantInfoScrollPanel = scrollTextPanel(this, content,
                        { // position
                        x: gameWidth/2, y: gameHeight/2-30, width: 680, height: 500}, 
                        doneButton
                        );
                }
                participantInfoScrollPanel.setVisible(true);

                enableButton(doneButton, 0);

                taskPhase = 'enablePracticeTasks';

                break;

            case 'enablePracticeTasks':

                enableButton(infoButton, window.infoSheetState)
                enableButton(quitButton, 1);
                enableButton(practPercGameButton, practPercGameState)
                enableButton(showPercInstructionsButton, practPercInstrState);
                enableButton(startPercPracticeButton, practPercPracticeState);
                enableButton(practMemGameButton, practMemGameState)
                enableButton(showMemInstructionsButton, practMemInstrState);
                enableButton(startMemPracticeButton, practMemPracticeState);

                for (let i = 0; i<numTaskBlocks; i++){
                    enableButton(taskButtons[i], window.finalTaskState[i])
                }

                if (spePractice){
                    clickConfidence = false;
                    taskPhase = 'spePractice';
                }
                else{
                    taskPhase = 'wait';
                }

                flickerText = helpTextInstr;
            
                break;

            case 'spePractice':
                currentConfidence = (speSlider.value);
                discreteConfidence = discretiseConfidence(
                        [currentConfidence],
                        window.numTaskTrials[0]+1)-1;
                text_conf.text = Math.round((discreteConfidence)/window.numTaskTrials[0]*100) + '% ('+
                                    (discreteConfidence) + '/' + window.numTaskTrials[0] + ') correct';
                switch (window.fruitvilleStage){
                    case 3:
                    case 7:
                        text_conf.x = 180;
                        text_conf.y = 440;
                        speSlider.x = 240;
                        speSlider.y = 420;        
                        break;
                    case 6:
                        text_conf.x = 450;
                        text_conf.y = 440;
                        speSlider.x = 550;
                        speSlider.y = 420;        
                        break;
                }
                text_conf.setVisible(true);
                speSlider.setVisible(true);
                
                if (clickConfidence &&
                    (Phaser.Input.Keyboard.JustDown(cursors.up) ||
                Phaser.Input.Keyboard.JustDown(cursors.down) ||
                Phaser.Input.Keyboard.JustDown(cursors.left) ||
                Phaser.Input.Keyboard.JustDown(cursors.right))){
                    // record spe

                    speSlider.setVisible(false);
                    text_conf.setVisible(false);
                    spePractice = false;

                    switch (window.fruitvilleStage){
                        case 3:

                            saveSPEData(window.subjID, window.expName, {
                                speNumCorrect: discreteConfidence,
                                curTaskBlock: 0,
                                taskType: 0
                            });
                            
                            practPercGameState = 2;
                            practPercInstrState = -1;
                            practPercPracticeState = -1;
        
                            practMemGameState = 1;
                            practMemInstrState = -1;
                            practMemPracticeState = -1;
        
                            this.children.bringToTop(helpTextInstr);
                            helpTextInstr.text = 'Click here to \npractice the >>\nsecond game';
                            helpTextInstr.x = 310;
                            helpTextInstr.y = 170;
                            taskPhase = 'enablePracticeTasks';
                            break;
                        
                        case 6:
                            saveSPEData(window.subjID, window.expName, {
                                speNumCorrect: discreteConfidence-1,
                                curTaskBlock: 0,
                                taskType: 1
                            });

                            practPercGameState = -1;
                            practPercInstrState = -1;
                            practPercPracticeState = -1;
        
                            practMemGameState = -1;
                            practMemInstrState = -1;
                            practMemPracticeState = -1;
                            
                            window.practiceOrFinal = [1,1];
                            taskPhase = 'practiceCompleteMessage';
                            break;    

                        case 7:
                            saveSPEData(window.subjID, window.expName, {
                                speNumCorrect: discreteConfidence-1,
                                curTaskBlock: 0,
                                taskType: 0
                            });

                            practPercGameState = -1;
                            practPercInstrState = -1;
                            practPercPracticeState = -1;
        
                            practMemGameState = -1;
                            practMemInstrState = -1;
                            practMemPracticeState = -1;
                            
                            window.practiceOrFinal = [1,1];
                            taskPhase = 'practiceCompleteMessage';
                            break;                            
                    }                    
                }
                break;

            case 'practiceCompleteMessage':

                mainText = ( " You have successfully completed the\n"+
                            " the Instruction and Practice phases.\n\n"+
                            " Click 'Proceed' to start the main \n"+
                            " game.\n"
                            );
                this.instructionsPanel = new InstructionsPanel(this, 
                gameWidth/2, gameHeight/2,
                2, "Practice Complete", mainText, "Proceed");            

                eventsCenter.once('page2complete', function () {
                    
                    nextTaskBtnIndex = 0; // button index of the next task
                    window.finalTaskState[nextTaskBtnIndex] = 1;
                    for (let i=1; i<numTaskBlocks; i++){
                        window.finalTaskState[i] = 0;
                    }
                    window.sret2State = 0;
                    // console.log(window.finalTaskState)
                    taskPhase = 'enableFinalTasks';
                }, this);

                flickerText = undefined;
                
                taskPhase = 'wait';
                
                break;

            case 'enableFinalTasks':

                enableButton(infoButton, window.infoSheetState);
                enableButton(quitButton,1);
                enableButton(practPercGameButton, practPercGameState)
                enableButton(showPercInstructionsButton, practPercInstrState);
                enableButton(startPercPracticeButton, practPercPracticeState);
                enableButton(practMemGameButton, practMemGameState)
                enableButton(showMemInstructionsButton, practMemInstrState);
                enableButton(startMemPracticeButton, practMemPracticeState);
                enableButton(sret2Button, sret2State);

                helpTextInstr.text = 'Complete the tasks below one at a time by\n  clicking the activated (blue) button';
                helpTextInstr.x = 150;
                helpTextInstr.y = 160;
    
                // console.log(window.finalTaskState)
                for (let i = 0; i<numTaskBlocks; i++){
                    enableButton(taskButtons[i], window.finalTaskState[i])
                }

                if (window.finalTaskState.slice(-1)==2){
                    // all tasks are complete 
                    taskPhase = 'thankyou';
                }
                else{
                    flickerText = helpTextInstr;
                    taskPhase = 'wait';
                }
            
                break;
                
            case 'speFinal':
                enableButton(infoButton, window.infoSheetState);
                enableButton(quitButton,1);
                enableButton(practPercGameButton, practPercGameState)
                enableButton(showPercInstructionsButton, practPercInstrState);
                enableButton(startPercPracticeButton, practPercPracticeState);
                enableButton(practMemGameButton, practMemGameState)
                enableButton(showMemInstructionsButton, practMemInstrState);
                enableButton(startMemPracticeButton, practMemPracticeState);
                enableButton(sret2Button, sret2State);

                helpTextInstr.text = 'Drag slider with green tick mark to estimate how\nmany trials you got correct on the last trial block.\n  Then press the right key (->) to proceed.';
                helpTextInstr.x = 130;
                helpTextInstr.y = 135;
                flickerText = helpTextInstr;
    
                for (let i = 0; i<numTaskBlocks; i++){
                    enableButton(taskButtons[i], window.finalTaskState[i])
                }

                currentConfidence = (speSlider.value);

                discreteConfidence = discretiseConfidence(
                [currentConfidence],
                window.numTaskTrials[window.taskPurpose[window.curTaskBlock-1]]+1)-1 ; // add 1 to the number of possible trial self-evaluations to include 0, then subtract 0 from the result
                
                // text_conf.text = (discreteConfidence) + '/' + window.numTaskTrials[1] + ' correct trials';
                text_conf.text = 
                Math.round((discreteConfidence)/window.numTaskTrials[window.taskPurpose[window.curTaskBlock-1]]*100) + 
                '% ('+
                (discreteConfidence) + '/' + window.numTaskTrials[window.taskPurpose[window.curTaskBlock-1]] + 
                ') correct';

                text_conf.x = taskButtons[window.curTaskBlock-1].x + 30*((window.curTaskBlock%2)*2 - 1) - 100;
                text_conf.y = taskButtons[window.curTaskBlock-1].y - 80*((window.curTaskBlock%2)*2 - 1) - 10;
                speSlider.x = taskButtons[window.curTaskBlock-1].x + 30*((window.curTaskBlock%2)*2 - 1);
                speSlider.y = taskButtons[window.curTaskBlock-1].y - 50*((window.curTaskBlock%2)*2 - 1);                     

                text_conf.setVisible(true);
                speSlider.setVisible(true);

                console.log("discreteConfidence"+discreteConfidence);
                
                if (clickConfidence &&
                    (Phaser.Input.Keyboard.JustDown(cursors.up) ||
                Phaser.Input.Keyboard.JustDown(cursors.down) ||
                Phaser.Input.Keyboard.JustDown(cursors.left) ||
                Phaser.Input.Keyboard.JustDown(cursors.right))){
                    // record spe

                    speSlider.setVisible(false);
                    text_conf.setVisible(false);
                    spePractice = false;

                    // console.log("discreteConfidence"+discreteConfidence);
                    // console.log("window.curTaskBlock"+window.curTaskBlock);
                    // console.log('blocksequence'+window.blockSequence);
                    // save the spe data and attach it to the data for the previous run
                    saveSPEData(window.subjID, window.expName, {
                        speNumCorrect: discreteConfidence,
                        curTaskBlock: window.curTaskBlock,
                        taskType: window.blockSequence[window.curTaskBlock-1]
                    });

                    

                    if (nextTaskBtnIndex == numTaskBlocks/2){
                        // after completing the first test block show the sret task button
                        window.sret2State = 1;
                        // 
                        taskPhase = 'sret2';
                    }
                    else if (nextTaskBtnIndex < numTaskBlocks-1){
                        // otherwise start the next fruitville task
                        window.finalTaskState[++nextTaskBtnIndex] = 1;
                        taskPhase = 'enableFinalTasks';
                    }
                    else{
                        // taskPhase = 'thankyou';
                        this.nextScene();
                    }
                }                

                break;

                case 'sret2':
                    // come here to start the second instance of the sret task
                    enableButton(sret2Button, sret2State);

                    helpTextInstr.text = 'Next, please do the second part\nof the self-description task before >>\nreturning to the Fruitville tasks';
                    helpTextInstr.x = 90;
                    helpTextInstr.y = 430;
                    flickerText = helpTextInstr;
    

        }

        if (flickerText!=undefined){
            // flicker flickerText if it is not undefined
            curFlickFrame++;
            if (curFlickFrame < flickerInstructionsFrames[0]){
                flickerText.setVisible(true);
            }
            else if (curFlickFrame < flickerInstructionsFrames[1]){
                flickerText.setVisible(false);
            }
            else {curFlickFrame=0;}            
        }        

    }

    createPercTaskButtons() {
        // first practice task is perception
        practPercGameButton = createButton(this, 
            "Practice Game\n'Berry Yield'",
        { // position
            x: 240, y: 200, width: 150, height: 80},
        function(scene) { // click callback
            practPercGameState = 2;
            practPercInstrState = 1;
            practPercPracticeState = 0;

            helpTextInstr.text = 'Instructions \nhere      >>';
            helpTextInstr.x = 9;
            helpTextInstr.y = 280;

            taskPhase = 'enablePracticeTasks';

        });
        practPercGameButton.setVisible(false);

        showPercInstructionsButton = createButton(this, "Game Instructions",    
        { // position
            x: 240, y: 300, width: 150, height: 50},
        function(scene) { // click callback
            scene.scene.start("perceptionTaskHelp");
        });
        showPercInstructionsButton.setVisible(false);

        startPercPracticeButton = createButton(this, "Start Practice",    
        { // position
            x: 240, y: 380, width: 150, height: 50},
        function(scene) { // click callback
            // let the task scene know that this is a practice version, so it can get the appropriate number of trials
            window.practiceOrFinal[curPracticeTask] = 0;
            scene.scene.start("perceptionTask");
        });
        startPercPracticeButton.setVisible(false);

    }

    createMemTaskButtons(){

        practMemGameButton = createButton(this, 
            "Practice Game\n'Fruit Box'",
        { // position
            x: 550, y: 200, width: 150, height: 80},
        function(scene) { // click callback
            practMemGameState = 2;
            practMemInstrState = 1;
            practMemPracticeState = 0;

            helpTextInstr.text = 'Instructions \nhere       >>';
            helpTextInstr.x = 310;
            helpTextInstr.y = 280;

            taskPhase = 'enablePracticeTasks';

        });
        practMemGameButton.setVisible(false);

        showMemInstructionsButton = createButton(this, "Game Instructions",    
        { // position
            x: 550, y: 300, width: 150, height: 50},
        function(scene) { // click callback
            scene.scene.start("memoryTaskHelp");
        });
        showMemInstructionsButton.setVisible(false);

        startMemPracticeButton = createButton(this, "Start Practice",    
        { // position
            x: 550, y: 380, width: 150, height: 50},
        function(scene) { // click callback
            // let the task scene know that this is a practice version, so it can get the appropriate number of trials
            window.practiceOrFinal[curPracticeTask] = 0;
            scene.scene.start("memoryTask");
        });
        startMemPracticeButton.setVisible(false);
        
    }

    createTextAndButtons(){

        titleText = 'Welcome to Fruitville!'
        
        mainText = (splitEssay(
            this.cache.text.get('welcomeFruitville'), 45)
                        );
        buttonTxt = "Proceed";
        pageNo = 1;

        bannerText = this.add.text(welcomTextCenter.x, 40, 'Welcome to Fruitville', {
            strokeThickness: 6, stroke: '#000', color: '#0e4',
            fontSize: 40
        });
        bannerText.setVisible(true);

        infoButton = createButton(this, '? Study Information',  
        { // position
            x: 275, y: 545, width: 100, height: 50},
        function() { // click callback
            // when info button is clicked show participant information sheet
            taskPhase = 'showParticipantInfoSheet';
        });
        enableButton(infoButton,0);

        sret2Button = createButton(this, 'Self-description\n  task - part 2',  
        { // position
            x: 575, y: 450, width: 100, height: 70},
        function(scene) { // click callback
            // when info button is clicked show participant information sheet
            window.nextSRET = 1;
            window.sret2State = 2;
            scene.scene.start("sreTask");

            window.finalTaskState[nextTaskBtnIndex] = 2;
            window.finalTaskState[++nextTaskBtnIndex] = 1;

        });
        enableButton(sret2Button, window.sret2State);

        text_conf = this.add.text(300,200,"",{
            align:'center', color: '#fff', strokeThickness: 3, 
            stroke: 'black',
            shadow: {offsetX: .5, offsetY: .5, stroke: true}
        });
        text_conf.scale = 1;
        text_conf.setVisible(false);

        doneButton = createButton(this, 'Understood',  
        { // position
            x: 640, y: 550, width: 100, height: 50},
        function() { // click callback
            participantInfoScrollPanel.setVisible(false);
            doneButton.setVisible(false);
            window.consentState = 1;
        });
        enableButton(doneButton, -1);

        quitButton = createButton(this, 'Quit Study', { // position
            x: 80, y: 545, width: 100, height: 50},
        function(scene) { // click callback
            quitStudyCallback(scene);
        });
        enableButton(quitButton, 1);
        
        helpTextInstr = this.add.text(200,200, "",
        {
            color: 'black', strokeThickness: 1.1, stroke: '#000',
            fontSize: 17
        });
        helpTextInstr.setVisible(false);

        speSlider = this.rexUI.add.slider({
            x: 380,
            y: 440,
            width: 250,
            height: 20,
            orientation: 'x',
            track: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[1]),
            indicator: this.rexUI.add.roundRectangle(0, 0, 0, 0, 15, window.sliderCols[3]),
            thumb: this.add.image(300,170,'tickMarkGreen').setScale(.4),
            input: 'click', // 'drag'|'click'
            valuechangeCallback: function (value) {
                clickConfidence = true;
            }}).layout();
        speSlider.setVisible(false); 

        fullscreenButton = addFullscreenButton(this);
    }

    nextScene() {
        window.mainTaskState = 2;
        window.mhq1State = 1;
        window.mhq2State = 1;

        this.scene.start('welcome');
    } 

}

var loadInfoSheet = function (scene){
    let cache = scene.cache.text;
    return cache.get('participantInfoSheet');
    // return content;
}


function specifyGroupSpecificParameters(subjGroup){
    // Using this is a function as it needs to wait for database access

    // first two blocks of tasks are baselines and are randomised in order
    let ftp = window.firstTwoBlocks;
    switch (subjGroup){
        case 1:
            window.blockSequence = [ftp, 1-ftp, 0, 1, 0, 1];
            window.feedbackType = [0, 0, 1, 0, 2, 0];
            window.sretOrder = [1, 2];
            break;
    
        case 2:
            window.blockSequence = [ftp, 1-ftp, 0, 1, 0, 1];
            window.feedbackType = [0, 0, 2, 0, 1, 0];
            window.sretOrder = [1, 2];
            break;
    
        case 3:
            window.blockSequence = [ftp, 1-ftp, 0, 1, 0, 1];
            window.feedbackType = [0, 0, 1, 0, 2, 0];
            window.sretOrder = [2, 1];
            break;
    
        case 4:
            window.blockSequence = [ftp, 1-ftp, 0, 1, 0, 1];
            window.feedbackType = [0, 0, 2, 0, 1, 0];
            window.sretOrder = [2, 1];
            break;
    
        case 5:
            window.blockSequence = [ftp, 1-ftp, 1, 0, 1, 0];
            window.feedbackType = [0, 0, 1, 0, 2, 0];
            window.sretOrder = [1, 2];
            break;
    
        case 6:
            window.blockSequence = [ftp, 1-ftp, 1, 0, 1, 0];
            window.feedbackType = [0, 0, 2, 0, 1, 0];
            window.sretOrder = [1, 2];
            break;
    
        case 7:
            window.blockSequence = [ftp, 1-ftp, 1, 0, 1, 0];
            window.feedbackType = [0, 0, 1, 0, 2, 0];
            window.sretOrder = [2, 1];
            break;
    
        case 8:
            window.blockSequence = [ftp, 1-ftp, 1, 0, 1, 0];
            window.feedbackType = [0, 0, 2, 0, 1, 0];
            window.sretOrder = [2, 1];
            break;
    
    }
}