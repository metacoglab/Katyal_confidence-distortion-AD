import InstructionsPanel from "./instructionsPanel.js";
import eventsCenter from './eventsCenter.js';
import { checkRepeatSubjects, getSubjectGroupAssignment, saveSubjGroup, saveSubjInfo } from "./db/saveData.js";
var gameHeight;
var gameWidth;
var fullscreenButton;
var smallFullScreenButton;

var subjInfo;
var taskPhase;
var helpTextInfo;

var prolificID;
var prolificIDField;
var subjGender;
var numStudiesDay;
var numStudiesMonth;
var getSubjGroup;

export default class SubjInfo extends Phaser.Scene
{
    constructor ()
    {
        super({
            key: 'subjectInfo'
        });
    }

    preload ()
    {
        this.load.scenePlugin({
            key: 'rexuiplugin',
            url: './src/phaser/rexuiplugin.min.js',
            sceneKey: 'rexUI'
        });  

        this.load.spritesheet('fullscreen', './assets/fullscreen.png', {frameWidth: 64, frameHeight: 64})
        this.load.text('sretWordsFinal', './assets/sretShort.txt');
        this.load.text('sretWordsPractice', './assets/sretPracticeWords.txt');

        this.load.image('bg', './assets/clouds.png');
        this.load.spritesheet('tiles', './assets/fantasy-tiles.png', { frameWidth: 64, frameHeight: 64 });
        this.load.html('infoform', 'src/utils/personalInfo.html');
    }

    create ()
    {
        // initialisations
        // background image
        this.add.image(400, 0, 'bg').setOrigin(0.5, 0.02);
        // tiles at the bottom
        for (let i = 0; i < 13; i++){
            this.add.image(64 * i, 580, 'tiles', 1).setOrigin(0);
        }

        gameHeight = this.sys.game.config.height;
        gameWidth = this.sys.game.config.width;

        fullscreenButton = addFullscreenButton(this);
                
        helpTextInfo = this.add.text(140,240, 
            " The next couple of tasks require exiting \n"+
            " the fullscreen mode.\n\n"+
            " Press the 'Escape' key OR click the    icon \n"+
            " on the top-right corner to leave fullscreen \n"+
            " mode and continue.",
        {
            color: 'black', strokeThickness: 1, stroke: '#000',
            fontSize: 18
        });
        smallFullScreenButton = this.add.image(540,295, 'fullscreen',1)
        .setOrigin(0,0).setScale(.3);
                
        taskPhase = 'stopFullscreen';

    }

    update ()
    {
        switch(taskPhase){

            case 'stopFullscreen':

                if (!this.scale.isFullscreen){
                    fullscreenButton.setFrame(0);
                    this.scale.stopFullscreen();
                    fullscreenButton.setVisible(false);
                    helpTextInfo.setVisible(false);
                    taskPhase = 'getInfo';
                    smallFullScreenButton.setVisible(false);
                }
                break;

            case 'getInfo':

                var mainText = (" Next, please provide us a little information\n" +
                                " about yourself... \n"
                                );
                this.instructionsPanel = new InstructionsPanel(this, 
                        gameWidth/2, gameHeight/2,
                        1, 'Information', mainText, "Proceed");

                eventsCenter.once('page1complete', function () {

                    var text = this.add.text(150, 160, 
                        'Please answer the following questions\n',
                        { color: 'white', fontSize: '20px ', align: 'center',
                    strokeThickness: 3, stroke: 'black'});
                
                    subjInfo = this.add.dom(370,350).createFromCache('infoform');
            
                    subjInfo.addListener('click');
            
                    subjInfo.on('click', function(event){
                        if (event.target.name == 'submitButton')
                        {
                            prolificIDField = this.getChildByName('idField');
                            prolificID = prolificIDField.value;
                            console.log(prolificID)

                            if (prolificID.slice(-1)==' '){
                                // if there is an extra space at the end, remove it
                                prolificID = prolificID.slice(0,-1);
                            }
                            subjGender = this.getChildByName('genderField');
                            numStudiesDay = this.getChildByName('numStudiesDay')
                            numStudiesMonth = this.getChildByName('numStudiesMonth');
                            
                            if (prolificID !== '' 
                            && subjGender.value !== undefined
                            && numStudiesDay.value !== undefined
                            && numStudiesMonth.value !== undefined){
                                // record age and gender
                                
                                // and move to sre
                                saveSubjInfo(window.subjID, window.expName, {
                                    prolificID: prolificID,
                                    gender: subjGender.value,
                                    numStudiesDay: numStudiesDay.value,
                                    numStudiesMonth: numStudiesMonth.value
                                });

                                taskPhase = 'assignGroup';
                            }
                            else{
                                this.scene.tweens.add({
                                    targets: text,
                                    alpha: 0.2,
                                    duration: 50,
                                    ease: 'Power3',
                                    yoyo: true
                                });
                            }
                        }
                    
                    });            

                    }, this);
            
                taskPhase = 'wait';
                break;
            
            case 'assignGroup':
                                
                /* ASSIGN SUBJECT GROUP
                1. first push the subject on to database to get a timestamp
                2. using that timestamp get the corresponding index for subject group
                3. if there is an error assign a group randomly from the possible choices
                */
                var checkRepeat = checkRepeatSubjects(prolificID, window.expName)

                checkRepeat.then(
                    function (value) {
                        if (value!=-1) {
                            // subject is repeated - use their previous group assignment
                            console.log('repeat subj: '+ value)
                            let repeatSubj = true;
                            groupAsssignment(value, repeatSubj); // no need to reassign group if id already found
                        }
                        else {
                            // if subject is new, then try to assign them to a group
                            getSubjGroup = getSubjectGroupAssignment(prolificID, window.expName); // this will be randomly assigned (for pilot task, we can use only groups 1-4)
                
                            getSubjGroup.then(
                                function(value) {
                                    // if assignment is successful
                                    let repeatSubj = false;
                                    groupAsssignment(value);
                                },
                                function() {
                                    // otherwise random
                                    let repeatSubj = false;
                                    groupAsssignment(-1);
                                });
                        }
                    },
                    function () {
                        // otherwise random
                        groupAsssignment(-1);
                    });

                taskPhase = 'wait';

                break;

            case 'nextScene':
                this.nextScene()
                break;
        }
    }
    
    nextScene() {

        this.scene.start('welcome');
    }

}

function groupAsssignment(value, repeatSubj){

    let subjGroupIndex;
    if (value==-1){
        // random group assignment
        console.log('no randomisation from database')
        subjGroupIndex = Math.floor(window.possibleSubjectGroups.length * Math.random());
    }
    else {
        subjGroupIndex = value;
    }
    window.subjGroup = window.possibleSubjectGroups[subjGroupIndex];

    console.log('subjGroup: ' + window.subjGroup);

    if (!repeatSubj){
        // save new subject if it is not a repeat subject
        saveSubjGroup(window.subjID, window.expName, subjGroupIndex);
    }

    taskPhase = 'nextScene';

}