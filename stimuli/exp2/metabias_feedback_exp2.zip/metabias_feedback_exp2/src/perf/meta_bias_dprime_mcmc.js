//var jstat = require('./node_modules/jstat')

var mb = require('./metad_bias/metad_bias.js')

// m,v = .2,.01; dp=1.5; mdp=1.8
var nR_S1 = [0, 0, 452, 2254, 1154, 762, 336, 5, 0, 0]; 
var nR_S2 = [0, 0, 2, 344, 833, 1136, 2241, 481, 0, 0];

// m,v = .8,.01; dp=2; mdp=1.6
var nR_S1 = [0, 2566, 315, 7, 0, 0, 4, 185, 581, 0];
var nR_S2 = [0, 564, 196, 5, 0, 0, 5, 352, 2571, 0];


fit = mb.fit_metad_bias_mcmc(nR_S1,nR_S2,'rate')

console.log("meta-d':")
console.log(fit.mdp)
console.log("bias a:")
console.log(fit.beta_a)
console.log("bias b:")
console.log(fit.beta_b)
console.log("mean:")
console.log(fit.beta_m)
console.log("var")
console.log(fit.beta_v)

