import InstructionsPanel from "./instructionsPanel.js";

import eventsCenter from './eventsCenter.js';
// import { stimulusGrid, numStimuli, numStimulusLevels, stim12, scaleFruit} from './eventsCenter.js';
// import { sceneSequence, curBlock} from './index.js';

const stimulusGrid = [10, 11]; // grid of berries
const numStimuli = stimulusGrid[0]*stimulusGrid[1]; // total number of berries
const numStimulusLevels = numStimuli/2; // number of stimullus levels

const stim12 = [0,1];
const scaleFruit = 0.14;

var berries;
var berry0;
var berry1;

export default class Instructions extends Phaser.Scene
{
    constructor ()
    {
        super({
            key: 'Instructions',
            // autoStart: true
        });
    }

    preload ()
    {
        // this.load.setBaseURL('http://127.0.0.1:5500');
        // this.load.setBaseURL('https://gitlab.pavlovia.org/sucharit/berries/tree/master/');

        this.load.image('tree','./assets/tree_2.png', { frameWidth: 500, frameHeight: 500 })
        this.load.image('bush1','./assets/bush_4.png', { frameWidth: 500, frameHeight: 500 })
        this.load.image('bush2','./assets/bush_9.png', { frameWidth: 500, frameHeight: 500 })
        this.load.spritesheet('diamonds', './assets/diamonds32x24x5.png', { frameWidth: 32, frameHeight: 24 });
        this.load.image('bg', './assets/clouds.png');
        this.load.spritesheet('tiles', './assets/fantasy-tiles.png', { frameWidth: 64, frameHeight: 64 });
        this.load.image('berry0', './assets/raspberry.png');
        this.load.image('berry1', './assets/black-berry-dark.png');    
        this.load.plugin(
            'rexrandomplaceplugin', 
            './src/phaser/rexrandomplaceplugin.min.js', 
            true);
            
    }

    create ()
{      
        // background image
        this.add.image(400, 0, 'bg').setOrigin(0.5, 0.02);
        // tree
        this.add.image(40, 310, 'tree').setOrigin(0.4, 0.5).setScale(1.2);
        // bushes
        this.add.image(430, 360, 'bush2').setOrigin(0.1, 0.5).setScale(1.2);
        this.add.image(300, 235, 'bush1').setOrigin(0.4, 0.5).setScale(1.6);

        // tiles at the bottom
        for (var i = 0; i < 13; i++)
        {
            this.add.image(64 * i, 580, 'tiles', 1).setOrigin(0);
        }


        
        var gameHeight = this.sys.game.config.height;
        var gameWidth = this.sys.game.config.width;
        
        var titleText = 'Welcome to Fruiteville!'
        
        // let's do this a long-winded way for easiness...[should be a function]
        ///////////////////PAGE ONE////////////////////
        var mainTxt = ( " The residents of Fruiteville need your help.\n" +
                        " Their main source of income is selling berries \n" + 
                        " that they grow. They need your help in deciding \n" +
                        " which berries give more yield. \n\n"+
                        " Is it Raspberries    or Blackberries    ? \n\n"+
                        " As the current market price for the two is the same\n"+
                        " they would like you to look at images captured from\n"+
                        " berry bushes from last year and help them decide  \n"+
                        " which of the two berries are greater in number.\n"
                        // "At regular points along your journey,\n"+
                        // "you will have to [color=#d0f4f7]make a choice[/color] between\n" +\n\n"
                        );
        var buttonTxt = "next page";
        var pageNo = 1;
        this.instructionsPanel = new InstructionsPanel(this, 
                                                       gameWidth/2, gameHeight/2,
                                                       pageNo, titleText, mainTxt, buttonTxt);
        berry0 = this.add.image(310,295,'berry0').setScale(.08);
        berry1 = this.add.image(585, 295,'berry1').setScale(.08);

        
        ///////////////////PAGE TWO////////////////////
        eventsCenter.once('page1complete', function () {
            // this.nextScene();

            berry0.setVisible(false);
            berry1.setVisible(false);
            mainTxt = (' You will see multiple "trials" with a number of  \n'+
                       " raspberries and blackberries within middle bush.\n" 
                      );
            pageNo = 2;
            this.instructionsPanel = new InstructionsPanel(this, 
                                                           gameWidth/2, gameHeight/2,
                                                           pageNo, titleText, mainTxt, buttonTxt);
            }, this);
        
        // eventsCenter.once('page2complete', function () {
        //             berries = this.add.group();
        //             // add reds
        //             berries.createMultiple({
        //                 key: 'fruit'+stim12[0],
        //                 setScale: {x: scaleFruit, y: scaleFruit},
        //                 // key: 'diamonds',
        //                 // frame: stim12[0],
        //                 frameQuantity: numStimulusLevels-5 // more red for stim=0
        //             });
        //             // add blues
        //             berries.createMultiple({
        //                 key: 'fruit'+stim12[1],
        //                 setScale: {x: scaleFruit, y: scaleFruit},
        //                 // key: 'diamonds',
        //                 // frame: stim12[1],
        //                 frameQuantity: numStimulusLevels+5
        //             });
        //             // Phaser.Actions.RandomRectangle(diamonds.getChildren(), ellipse);
        //             this.plugins.get('rexrandomplaceplugin').randomPlace(berries.getChildren(),
        //                 {
        //                     radius: 10,
        //                     area: new Phaser.Geom.Rectangle(230, 300, 300, 260),
        //                 });
        //             Phaser.Actions.SetVisible(berries.getChildren(),1);
        //             // this.scene.pause();
        //         }, this);            

        // ///////////////////PAGE THREE////////////////////
        // eventsCenter.once('page2complete', function () {
        //     mainTxt = ("  It is therefore up to you to [color=#d0f4f7]decide[/color], at each  \n"+
        //                "crossing, [color=#d0f4f7]which route you want to take[/color].\n\n" +  

        //                "Remember, you will earn a [color=#FFD700]real bonus payment[/color],\n" +
        //                "depending on how many coins you collect!"+
        //                "\n\n" +
                       
        //                "Before you start the real game, you will have\n" +
        //                "  a chance to practice powering up your umbrella.  "+
        //                "\n\n" + 

        //                " When you are ready,\n" +
        //                "press [b]start practice[/b] to begin.\n");
        //     buttonTxt = "start practice"
        //     pageNo = 3;
        //     this.instructionsPanel = new InstructionsPanel(this, 
        //                                                    gameWidth/2, gameHeight/2,
        //                                                    pageNo, titleText, mainTxt, buttonTxt);
        //     }, this);
        
        // end scene
        eventsCenter.once('page2complete', function () {
            this.nextScene();
            }, this);

        // //  Input Events
        // cursors = this.input.keyboard.createCursorKeys();

        // shiftKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SHIFT);

    }

    update ()
    {

        // text_instr.setVisible(true);

        // if (Phaser.Input.Keyboard.JustDown(shiftKey))
        // {

        //     text_instr.setVisible(false);
        // }        


    }

    nextScene() {
        console.log((window.sceneSequence[window.curBlock]))
        this.scene.start(window.sceneSequence[window.curBlock]);
    } 

}

